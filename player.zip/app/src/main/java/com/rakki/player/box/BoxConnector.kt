package com.rakki.player.box

import android.os.Handler
import android.os.Looper
import okhttp3.*
import java.io.IOException

object BoxConnector {
    private val client = OkHttpClient()

    fun sendStreamToBox(boxIp: String, streamUrl: String, title: String, callback: (Boolean, String) -> Unit) {
        val targetBoxUrl = "http://$boxIp:7777/play"
        val jsonBody =okhttp3.RequestBody.create(
            MediaType.parse("application/json; charset=utf-8"),
            "{\"url\":\"$streamUrl\",\"title\":\"$title\"}"
        )

        val request = Request.Builder()
            .url(targetBoxUrl)
            .post(jsonBody)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Handler(Looper.getMainLooper()).post { callback(false, e.message ?: "Connection Failed") }
            }

            override fun onResponse(call: Call, response: Response) {
                val success = response.isSuccessful
                Handler(Looper.getMainLooper()).post { callback(success, if (success) "Sent Successfully" else "HTTP Error: ${response.code}") }
            }
        })
    }
}
