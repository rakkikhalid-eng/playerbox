package com.rakki.tvplayer

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import fi.iki.elonen.NanoHTTPD
import com.google.gson.Gson
import com.google.gson.JsonObject

class TvMainActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var txtLog: TextView
    private var receiverServer: ReceiverServer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tv_main)

        playerView = findViewById(R.id.playerView)
        txtLog = findViewById(R.id.txtLog)

        initializePlayer()

        try {
            receiverServer = ReceiverServer(7777) { url, title ->
                runOnUiThread {
                    txtLog.text = "Received Play Request: $title\nURL: $url"
                    playUrl(url)
                }
            }
            receiverServer?.start()
            txtLog.text = "TV Receiver Server started on port 7777. Waiting for cast..."
        } catch (e: Exception) {
            txtLog.text = "Server Error: ${e.message}"
        }
    }

    private fun initializePlayer() {
        player = ExoPlayer.Builder(this).build().also {
            playerView.player = it
        }
    }

    private fun playUrl(url: String) {
        player?.let {
            val mediaItem = MediaItem.fromUri(url)
            it.setMediaItem(mediaItem)
            it.prepare()
            it.play()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        player?.release()
        receiverServer?.stop()
    }

    class ReceiverServer(port: Int, private val onPlayCallback: (String, String) -> Unit) : NanoHTTPD(port) {
        override fun serve(session: IHTTPSession): Response {
            if (session.method == Method.POST && session.uri == "/play") {
                val map = HashMap<String, String>()
                session.parseBody(map)
                val postBody = map["postData"] ?: ""
                try {
                    val json = Gson().fromJson(postBody, JsonObject::class.java)
                    val url = json.get("url").asString
                    val title = json.get("title").asString
                    onPlayCallback(url, title)
                    return newFixedLengthResponse(Response.Status.OK, MIME_PLAINTEXT, "OK")
                } catch (e: Exception) {
                    return newFixedLengthResponse(Response.Status.BAD_REQUEST, MIME_PLAINTEXT, "Invalid JSON: ${e.message}")
                }
            }
            return newFixedLengthResponse(Response.Status.NOT_FOUND, MIME_PLAINTEXT, "Not Found")
        }
    }
}
